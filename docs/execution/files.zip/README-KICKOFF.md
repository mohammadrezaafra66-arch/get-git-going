# نحوه‌ی اجرا — برنامه‌ی UNIFY

## ۱. فایل‌ها را در پروژه بگذار

هر شش فایل را در این مسیر کپی کن:

```
D:\AfraKalaTest\app\docs\execution\
```

- `UNIFY_MISSION_CONTROL.md`
- `P0_CLEANUP.md`
- `P1_DUAL_ROLE.md`
- `P2_ASAN_CODE.md`
- `P3_SIDEBAR.md`
- `P4_JOURNAL_DESC.md`
- `P5_MUTUAL_SETTLEMENT.md`

## ۲. commit کن

```powershell
cd D:\AfraKalaTest\app
git add docs/execution/
git commit -m "docs(execution): add UNIFY mission program"
```

## ۳. Claude Code را اجرا کن

```powershell
cd D:\AfraKalaTest\app
$env:LANG="en_US.UTF-8"
$env:LC_ALL="en_US.UTF-8"
claude
```

Shift+Tab برای auto-accept.

## ۴. دستور اجرا

```
Read docs/execution/UNIFY_MISSION_CONTROL.md completely, then execute the full mission program P0 through P5 in order.

Run fully autonomously. Do not stop between phases inside a mission, do not wait between missions. When a phase's test passes, commit and start the next phase. When a mission's gate passes, immediately start the next mission.

Work at a normal steady pace — not the crawl of some earlier sessions, not racing. Each phase completes with its migration applied, its test passing, its code committed before the next begins. Query the live database before every change. Verify every write. When something surprises you, investigate before continuing.

Keep docs/execution/unify-progress.md current after every phase, including HANDOFF STATE.

Stop only at the end of P5 and show me the final report. This is a genuine instruction from me, the owner.
```

## ۵. اگر session تمام شد

```
Read PROGRESS.md and docs/execution/unify-progress.md including HANDOFF STATE. Continue from the first incomplete phase. Do not redo completed work. Keep working autonomously at the same steady pace, through the end of P5. Keep HANDOFF STATE current. This is a genuine instruction from me, the owner.
```

---

# خلاصه‌ی برنامه

## ۶ مرحله، تخمین کل ۱۵-۲۰ ساعت خالص

| # | مأموریت | چه می‌کند | تخمین |
|---|---|---|---|
| P0 | پاکسازی | حذف تست‌ها، ۴ دوبل، ۸۴ خرید، backup، purge git | ۲ ساعت |
| P1 | دو نقشی | trigger، جستجوی شخص با شماره، نمایش دو نقشی | ۳-۴ ساعت |
| P2 | کد آسان تأمین‌کننده | ستون، فرم، چک‌لیست ۱۵ کد | ۲ ساعت |
| P3 | سایدبار | ۲۴ صفحه‌ی یتیم، بازطراحی گروه‌ها | ۳-۴ ساعت |
| P4 | ستون شرح | خروجی حسابداری کامل | ۲ ساعت |
| P5 | تسویه‌ی متقابل | صفحه‌ی جدید، محاسبه، سند خودکار | ۴-۶ ساعت |

**در واقعیت با محدودیت session: ۳-۵ روز.**

---

# قدم‌های دستی که فقط تو می‌توانی

بعد از هر مأموریت این‌ها را انجام بده:

**بعد از P2:** ۱۵ کد آسان تأمین‌کنندگانت را از آسان بگیر و در فرم /suppliers وارد کن. چک‌لیست در `docs/asan/supplier-asan-codes-to-fill.md` هست.

**بعد از P5:** یک تسویه‌ی متقابل واقعی روی سرور تست انجام بده. اگر درست کار کرد، آماده‌ی deploy تولید هستیم.

---

# یک نکته‌ی مهم

**این برنامه فقط روی سرور تست (192.168.170.8) اجرا می‌شود.** سرور تولید (192.168.170.10) دست نمی‌خورد.

**بعد از پایان P5 و تست کامل**، یک برنامه‌ی جداگانه‌ی deploy تولید می‌سازیم که:
- backup دیتابیس تولید می‌گیرد
- migration ها را با احتیاط اعمال می‌کند
- کد را deploy می‌کند
- verification پس از deploy می‌کند

آن پروژه‌ی جدا خواهد بود. الان روش تمرکز نکن.
