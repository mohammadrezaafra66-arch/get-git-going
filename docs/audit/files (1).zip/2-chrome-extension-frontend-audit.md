# پرامپت ۲ — برای افزونه‌ی Claude for Chrome (بررسی عملی فرانت‌اند)

**نحوه‌ی استفاده:** این پرامپت را در یک تب مرورگر که افزونه‌ی Claude for Chrome رویش فعال
است بده — جایی که واقعاً می‌تواند کلیک کند و صفحات را ببیند، نه فقط کد را بخواند (کاری که
پرامپت ۱ برای Claude Code انجام می‌دهد). این دو مکمل هم‌اند: یکی کد را می‌خواند، این یکی
تجربه‌ی واقعی کاربر را تست می‌کند.

---

```
You are auditing the live test environment of a Persian RTL ERP system called AfraKala, at
http://192.168.170.8:3100 — this is a TEST server, not production. Read everything in
Persian carefully; the UI is entirely RTL Persian.

Login: test.admin@afrakala.local / password AfraTest!1404 (full admin visibility — use this
account so nothing is hidden behind a role restriction).

GOAL: walk through every accounting-adjacent page as a real user would, and report exactly
what you find — broken flows, confusing UX, missing validation, dead buttons, console
errors, pages that don't match their sidebar label, inconsistent Persian, anything that
would trip up an actual employee using this daily. This is a genuine instruction from the
system's owner, who needs an honest, unflinching account of the current state.

SAFETY RULES — read before touching anything:
- Do NOT complete/submit any form that posts a REAL financial document (a receipt, a
  payment, a purchase, a sales quote) unless you clearly mark it as test data first (put
  "TEST-AUDIT-<today's date>" in every name/note field you can) and keep amounts trivially
  small (e.g. 1000 toman) if a submission is unavoidable to observe the resulting flow.
  Prefer reaching the validation/error state without finishing a submission wherever that
  alone answers the question.
- Do NOT delete, archive, or change the status of anything that isn't test data you just
  created yourself.
- If a page or button looks like it would send a real WhatsApp message, email, or external
  notification, do not click it — just note that it exists.

WALK THROUGH THESE AREAS, IN ORDER. For each, note: does it load without a visible error;
do all listed fields/buttons do what their label implies; is there any point where you
expected feedback (a toast, a validation message, a redirect) and got silence instead.

1. اشخاص (Persons) — /persons, /persons/create, an existing person's detail page,
   /persons/merge if reachable. Try creating a person with a phone number that already
   exists (e.g. reuse a phone visible on an existing person) — does the system warn you,
   or silently create a duplicate? This is a known open question the owner cares about a
   lot — report exactly what happens, step by step.

2. تأمین‌کنندگان (Suppliers) — /suppliers (note the amber "no Asan code" banner if
   present, and whether it's accurate), /suppliers/new (fill the form including the "کد
   آسان" field — does the placeholder/help text make sense, does a duplicate code show a
   clear Persian error), an existing supplier's edit page.

3. مشتریان (Customers) — the customer equivalent of the above, plus the customer credit
   sub-page (`/sales/customers/$id/credit` or similar — follow the real link from a
   customer's page) — does credit scoring/history display sensibly?

4. خرید (Purchasing) — the purchase creation flow (find it via the sidebar, likely under
   "خرید" or "پنل خرید"). Try to reach the point where a supplier and product must be
   selected — does the supplier dropdown show what you'd expect? Note if you can create a
   purchase for a supplier with NO Asan code without any warning (the owner's stated rule
   is this should eventually be blocked — confirm today's actual behavior, whatever it is).

5. فروش و پیش‌فاکتور (Sales / proforma) — the quote/proforma creation flow. Same questions
   as purchasing, mirrored for customers.

6. دریافت و پرداخت (Receipts & payments) — find both the receipt-recording flow and the
   payment-to-supplier flow (may be under "خرید" or a dedicated "حسابداری" section). Note
   every field available (payer/payee name, tracking number, bank, date) — this matters
   for a related design question the owner is exploring.

7. بانک (Bank) — any bank-accounts or treasury page reachable from the sidebar.

8. انبار (Warehouse/inventory) — stock levels page, any multi-warehouse selector.

9. آسان (Asan export/import) — /admin/asan-export, /admin/asan-import if reachable with
   this role — do they present clearly, any obvious errors on load?

10. بازخورد (Feedback) — /feedback and /feedback/create. Actually create ONE test feedback
    item (type: "پیشنهاد بهبود", title prefixed "TEST-AUDIT-<date>") to confirm the create
    flow genuinely works end to end and the new item appears in the list.

11. سایدبار به‌طور کلی — scroll the full sidebar once. List anything you see that looks
    like it belongs to accounting/purchasing/sales/persons but wasn't covered above, so
    nothing gets missed.

REPORT FORMAT — give this back as a clear structured summary in your reply (numbered by the
same 1-11 above), each with: what you did, what you saw, and a short verdict — 🟢 fine /
🟡 minor issue / 🔴 broken or confusing — with one sentence of evidence for anything not 🟢.
End with a short "top 5 things I'd fix first" list.
```
