# پرامپت ۱ — برای Claude Code (تحقیق جامع حسابداری و اشخاص)

**نحوه‌ی استفاده:** این را در یک session تازه‌ی Claude Code، داخل `D:\AfraKalaTest\app` بده.
چون حجم کار زیاد است، به آن اجازه‌ی چند session بده — HANDOFF STATE را در فایل جداگانه نگه می‌دارد.

---

```
Read PROGRESS.md, CLAUDE.md/AGENTS.md before starting. This is a genuine instruction from
the owner, Mohammad Reza Afra.

Task: an exhaustive, read-only, evidence-based research audit of every accounting-adjacent
and person-adjacent capability in AfraKala. This is deliberately broad and deep — the owner
explicitly wants "بسیار بسیار کامل" (very, very thorough) coverage, not a summary. Expect
this to take multiple sessions. That is fine and expected.

Do NOT fix, build, or change anything. Investigation only. No code, no migrations.

============================================================
CONTEXT — five things discovered in a prior business-logic discussion with the owner,
all of which need real investigation here, not assumption:
============================================================

1. THIRD-PARTY / PASS-THROUGH PERSON. The owner described a real scenario: customer A
   owes the business money. The business owes supplier B money. B asks the business to pay
   his sister C directly (C is not A, B, or a customer/supplier of the business at all).
   The business either (a) writes two documents — a receipt from A, a payment to B, both
   noting "paid via C" — or (b) writes ONE balanced dual-entry document crediting A's
   receivable and debiting B's payable in a single transaction, with C's info (name, date,
   tracking number, bank account, time) captured somewhere. The owner does NOT want a full
   person/customer/supplier record created for C. He wants C's info to be queryable later
   (e.g. "show everything sent to this bank account/name over the past year"), but NOT a
   full "پرونده" (case file) with a ledger. Investigate whether `external_party` (one of
   the six allowed values in `journal_lines.account_kind`) is meant for exactly this, and
   how it currently works, if at all.

2. PERSON GROUPS/SUBGROUPS. The owner wants persons to be assignable to multiple
   groups AND subgroups simultaneously (e.g. "customers" group AND "Tabriz province" group
   AND "Azarshahr city" group, all at once), with full CRUD — add to a group, remove from a
   group, move between groups, edit group membership, at any time (not just at creation).
   A GitHub check by the owner's other assistant already found: no `groups`/`person_groups`
   table exists — only `categories` (product-scoped) does. CONFIRM this live against the
   real database (don't trust a prior claim), and if genuinely absent, propose 2-3 concrete
   schema designs for how such a system could be built, consistent with this codebase's
   existing patterns (e.g. how `person_context_links` models context_kind today, RLS
   conventions, audit-trigger conventions already in use elsewhere).

3. ASAN CODE REQUIRED ONLY AT DOCUMENT-CREATION TIME. The owner corrected an earlier
   position: an Asan code is NOT required for a person to exist in the system or belong to
   any group (including "suppliers"). It IS required the moment anyone tries to create an
   actual accounting document for that person — a پیش‌فاکتور (proforma invoice), a سند دوبل
   (dual-entry/journal document), a سند دریافت (receipt), or a سند پرداخت (payment). The
   required UX: if the person lacks a code at the moment of document creation, an inline
   dialog opens to register it right there, then the document proceeds — the user should
   never be bounced out of the flow. The owner also wants this enforced as a real database
   rule, not just a UI nicety (client-side checks alone can be bypassed via direct PostgREST
   writes — this codebase has hit that exact trap before). Investigate whether ANY such
   enforcement exists today, anywhere, for any of the four document types — expect the
   answer is "no, only export is blocked" (confirmed for suppliers in migration 308/P2),
   but verify precisely and check customers too.

4. CROSS-PERSON DUAL-ENTRY DOCUMENT. The real example in point 1 involves TWO DIFFERENT
   people (a customer's receivable, a supplier's payable) cleared against each other in
   ONE balanced journal entry — not the same person netting their own combined position
   (which is what earlier P5 planning assumed). Investigate whether the schema/RPCs can
   currently express "debit person X's payable + credit person Y's receivable, balanced,
   one transaction" at all, regardless of whether X and Y are the same person.

5. EMPLOYEE FEEDBACK MECHANISM. A `/feedback` route was found, backed by a `feedback_items`
   table, with types (bug/process_issue/improvement/operational) and a status workflow
   including "converted_to_task". This looks complete on the frontend list page. VERIFY it
   end-to-end: does `/feedback/create` actually work and write correctly? What is the real
   RLS on `feedback_items` (can a submitter see only their own, can admin/manager see all,
   exactly as the list page assumes)? Is "converted_to_task" wired to actually create a row
   in `tasks`, or does the status just sit there unimplemented (this project's most common
   pattern — "built but never wired")? Give a definitive, evidence-based verdict.

============================================================
PER-DOMAIN CHECKLIST — apply this exact 8-point checklist to EACH domain listed below.
Do not skip points; do not guess — discover schema live via information_schema, pg_get_
functiondef, pg_policies, and role_permissions, per Mission Control rule 2.6.
============================================================

For domain X, answer:
  1. Routes/pages: every route file backing X, its role visibility, and its nav registry
     entry (or confirm it has none — an orphan).
  2. Schema: every table/column backing X, discovered live (not assumed from naming).
  3. Business logic: every RPC/trigger/function implementing X's rules — read with
     pg_get_functiondef, quote the relevant logic, don't paraphrase from memory.
  4. Constraints: every CHECK/UNIQUE/FK currently governing X.
  5. Built-but-unwired: routes with no nav entry, tables with zero or near-zero rows,
     functions that exist but are never called from any route/component.
  6. Duplication: two or more components/functions/routes doing the same job under
     different names.
  7. Bugs/gaps: anything demonstrably broken — a wrong column reference, a silent RLS
     zero-rows case, a missing validation, a UI/RPC contract mismatch. Evidence required:
     file:line, or a SQL query + its live result, or a reproduced error.
  8. role_permissions coverage: does every module touching X have explicit rows for every
     role in `role_permissions`? Flag any gap — `has_dynamic_permission` silently opens an
     un-seeded module to ALL roles, which is a security gap, not just a UX one.

Apply the 8-point checklist to each of these domains:

  A. تأمین‌کنندگان (Suppliers) — include: does `trust_level` (low/medium/high) actually
     drive anything downstream (filtering, reporting, decision support), or is it purely
     decorative today? Confirm current state of `dynamic_entity_scores` excluding suppliers
     by CHECK (found in an earlier round of research — re-verify it still holds after
     migrations 303-310).
  B. مشتریان (Customers) — include: how customer credit scoring actually works end to end,
     and whether it has the same trust_level-is-decorative risk.
  C. خرید (Purchasing) — purchases, purchase_requests, purchase_items, the RPC(s) that
     create them, purchase_request_fulfillments and the derived-status trap already found
     once (migration 304/306 history).
  D. فروش و پیش‌فاکتور (Sales & proforma invoices) — sales_quotes (the real business table,
     not `invoices` which has 0 rows), quote → invoice lifecycle if any, proforma-specific
     rules.
  E. دریافت (Receipts) — payment_receipts, its accounting-posting path
     (post_receipt_accounting), which fields exist today for payer name / tracking number
     / settlement target, and whether any of them already resemble the third-party capture
     need in point 1 above.
  F. پرداخت (Payments) — payment_vouchers. Re-confirm the finding from earlier research
     that payment_vouchers currently posts NO journal entry at all (if still true, this is
     a major gap: outgoing payments are invisible to double-entry). Get an exact, current
     row count and a concrete example.
  G. سند دوبل / دفتر روزنامه (Dual-entry / journal) — journal_entries, journal_lines,
     account_kind's exact allowed values today, and whether a single balanced entry
     spanning two DIFFERENT people (per point 4) is currently constructible via any
     existing RPC, or would need new code.
  H. بانک (Bank) — bank accounts, treasury pages found in earlier navigation research
     (11 finance items with no role_permissions rows — re-verify this is still true).
  I. انبار (Warehouse/inventory) — stock_movements (note: polymorphic ref_type/ref_id with
     NO foreign key — a known hazard from migration 304), current stock calculation logic,
     multi-warehouse support if any.
  J. چک، سفته، برات (Cheques, promissory notes, drafts) — confirm precisely what does and
     does not exist. Prior research says "not supported" — get the exact current state:
     is there even a placeholder table/column, or truly nothing?

============================================================
OUTPUT
============================================================

Because of the scope, structure the output as:

1. `docs/audits/full-accounting-audit.md` — the main report. One H2 section per domain
   (A through J) following the 8-point checklist, plus a dedicated section for each of the
   five context items (1-5) at the top. Every claim: file:line, or SQL + result, or a
   reproduced error. No claim without evidence.

2. `docs/audits/accounting-audit-progress.md` — a HANDOFF STATE file, same pattern as
   `docs/execution/unify-progress.md`: which domains are done, which remain, exact resume
   point. Update this after every domain, in case the session ends mid-way.

3. End the main report with:
   - **خلاصه‌ی مدیریتی** (executive summary): the 10 most important findings, ranked by
     how much they block the owner's stated goals (third-party capture, groups/subgroups,
     Asan-at-document-creation enforcement, cross-person dual-entry).
   - **پیشنهاد معماری** for items 1-4 above: 2-3 concrete design options each, with
     tradeoffs, consistent with this codebase's existing conventions. Propose, do not
     implement.

Constraints:
- Read-only. git status clean at start; only the two report files should change by the end.
- No typecheck, no e2e, no migrations, no code changes of any kind.
- Commit incrementally as domains complete (one commit per 2-3 domains is fine, so
  progress survives a session boundary). Message pattern:
  `docs(audit): accounting audit — domains <X,Y> complete`
- If you hit a session limit, write HANDOFF STATE and stop cleanly. On resume, read
  `docs/audits/accounting-audit-progress.md` and continue from the first incomplete domain.
  Never redo completed work.

When genuinely finished with everything (context items 1-5 + all ten domains A-J), stop
and show the owner the report. This is a genuine instruction from me, the owner.
```
