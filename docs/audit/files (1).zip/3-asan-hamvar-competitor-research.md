# پرامپت ۳ — تحقیق در نرم‌افزار آسان و «حسابداری هموار»

**نحوه‌ی استفاده:** این را می‌توانی همین‌جا از من بخواهی اجرا کنم (وب‌سرچ دارم)، یا در یک
گفتگوی تازه‌ی claude.ai بدهی — بخصوص اگر بخواهی از قابلیت Research (تحقیق عمیق چندمنبعی)
استفاده کنی. هر دو حالت کار می‌کند؛ متن پرامپت یکسان است.

**محدودیت واقع‌بینانه‌ای که باید بدانی:** این تحقیق فقط می‌تواند صفحات عمومی (سایت
بازاریابی، مستندات پشتیبانی، ویدیوهای آموزشی، فروم‌ها) را ببیند — نه داخل نرم‌افزار واقعی
که نیاز به لاگین دارد. پس جواب‌ها احتمالاً «تا این حد از مستندات عمومی معلوم است» خواهند
بود، نه قطعی صددرصد. این برای جهت‌گیری طراحی کافی است، نه منبع نهایی.

---

```
Research task: investigate how two Iranian accounting/ERP software products — آسان
(Asan, at asan7.ir) and its newer web-based sibling "حسابداری هموار" (Hamvar Accounting) —
handle a specific set of business-accounting challenges, so the findings can inform design
decisions for a comparable in-house system (AfraKala).

Use web search and fetch actual pages (marketing pages, help/support docs, video tutorial
descriptions, community forum discussions) — do not rely on general prior knowledge alone
for anything specific to these two products, since they are niche Iranian software and
generic training data is unlikely to cover their specifics accurately.

============================================================
THE SPECIFIC CHALLENGE TO FOCUS ON
============================================================

A real scenario: Customer A owes the business money. The business owes Supplier B money.
B asks to be paid via a bank account belonging to a third party C (e.g. his sister) — C is
not a customer or supplier of the business in any other respect. The business needs to:
  (a) record that A's debt was settled and B's debt was settled, in one coherent
      transaction or a clearly linked pair of transactions,
  (b) keep C's identifying info (name, account number, tracking number, date, amount)
      somewhere searchable for later reference (e.g. "what did we send to this person/
      account over the past year"),
  (c) WITHOUT creating a full customer/supplier "file" (پرونده/کاردکس) for C — she should
      not appear as a person with her own ledger/balance in the system.

Specific questions to answer about EACH product (Asan, Hamvar):
  1. Does it support a "دوبل" style single balanced document that debits one party's
     payable and credits a DIFFERENT party's receivable in one transaction? What is this
     feature called in their UI/docs, and how is it described?
  2. Is there a concept of a "طرف سوم" / "واسط" / "ذی‌نفع پرداخت" (third-party payee/
     beneficiary) distinct from a full customer/supplier record — i.e. a lightweight,
     document-level capture of who actually received funds, without creating a person
     entity for them? What is it called, and what fields does it capture?
  3. How does the product handle person/party grouping — can one party (customer/supplier/
     contact) belong to multiple groups or categories simultaneously (e.g. a role group
     AND a geographic group)? Is there a "زیرگروه" (subgroup) concept?
  4. Does the product require an accounting code (their equivalent of "کد آسان") to exist
     BEFORE a person can be created/added at all, or only at the moment an actual financial
     document is created for them? How is this enforced in the UI (inline prompt vs. hard
     block elsewhere)?
  5. General feature coverage, for context: how do they structure دریافت (receipts),
     پرداخت (payments), چک/سفته/برات (cheques/promissory notes/drafts — note whether these
     ARE supported, since AfraKala currently does not support them at all), انبار
     (multi-warehouse inventory), بانک (bank/treasury), خرید و فروش و پیش‌فاکتور
     (purchase/sales/proforma).

============================================================
OUTPUT
============================================================

A clear comparison write-up, organized by the 5 questions above, each with:
- What Asan does (with source: which page/doc, and a brief paraphrase — never quote
  verbatim text at length)
- What Hamvar does (same)
- Where they differ, if they do
- A design implication for AfraKala: "if we wanted to match/exceed this, we'd need X"

End with a short recommendation: which of the two (if either) seems to have solved the
third-party pass-through problem in a way worth learning from, and why.

Keep quotes minimal and short throughout — paraphrase in your own words; this is a design
research summary, not a reproduction of their documentation.
```
